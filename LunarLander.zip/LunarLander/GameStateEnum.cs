﻿namespace CS5410
{
    public enum GameStateEnum
    {
        MainMenu,
        GamePlay,
        HighScores,
        Settings,
        Credits,
        Exit
    }
}
